import React from "react";
import southernImg from './images/Southern.png'
import northernImg from './images/Northern.png'
import eucadorImg from './images/ecuador.gif'

const Hemisphere_Display = (props) => {
    const hemisphereResult = props.latitude
    let userLocation=''
    let picture
    if(hemisphereResult>0){
    userLocation='North Hemisphere!'
    picture = northernImg
    }

    else if (hemisphereResult<0){
        userLocation='Southern Hemisphere!'
        picture = southernImg
    }
    
    else {
        userLocation='You are at the Ecuadorian line!'
        picture = eucadorImg
    }

        return(
        <div>
            <p>Welcome to hemisphere app</p>
            <p>You are at <span>{props.atitude}</span></p>
            <img scr={picture} style={{width:'50%'}}/>
        
        </div>
        )
    
        }

export default Hemisphere_Display;