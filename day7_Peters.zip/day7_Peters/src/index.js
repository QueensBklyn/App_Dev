import React from 'react';
import ReactDOM from 'react-dom/client';
import User from './comments';
import avatar_doctor from './images/doctor.png'
import avatar_afro from './images/afro.svg'
import User_feedback from './UserFeedback'


const App = function(){
  return(
 <div className='ui comments'>
  <User_feedback>    
   <User
    name='Mr. Happy'
    date='09:30AM'
    msg="I'm feeling amazing"
   picture={avatar_doctor}
    />
   </User_feedback>
   <User_feedback> 
   <User
     name='Ms. Joy'
     date='03:30AM'
     msg="I'm feeling joyous"
     picture={avatar_afro}
   />
   </User_feedback>
   <User_feedback>
   <User
    name='Ms. Glad'
    date='01:30PM'
    msg="I'm feeling glad"
    picture={avatar_doctor}
    />
    </User_feedback>
   </div>

  )
}


//rooting
const root =ReactDOM.createRoot(document.querySelector('#root'))
root.render(App())


/*
//example of props
const App = function(props) {
  return(
    <div>
      <h1>Welcome to React function components{PaymentResponse.name}</h1> 
      </div>
  )
  }
// create a props in a constant
const myElement= <App name='Martha'/>


//rooting
ReactDOM.render(
  myElement, document.querySelector('#root')
)
*/



