import { Component } from '@angular/core';
import { User } from './user.model';
import { UserRepository } from './respository.model';

@Component({
  selector: 'user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  model: UserRepository = new UserRepository()
  newUser:User = new User()

  get jsonUser(){
    return JSON.stringify(this.newUser)
  }

  addUser(u:User){
    console.log('New user is: ' + this.jsonUser)
  }
  displayLog(model:any){
    console.log(model)
  }

  //validation rule
  formSubmit:boolean =false
  
  //ngForm
  submitForm(form:any){
    console.log(form)
  }
}
