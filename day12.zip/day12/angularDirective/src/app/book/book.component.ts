import { Component } from '@angular/core';
import { BookRespository } from './repository.model';
import { Book } from './book.model';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent {
  model:BookRespository = new BookRespository()
  books: any;

  addBook(){
    this.model.addBook(new Book(4, 'Kids Science', 'National Geographic', 56))
   }

   deleteBook(book:Book){
    this.model.deleteBook(book)
   }
    
    updateName(book:Book){
      book.name='UPDATED NAME'
    }

    updatePrice(booK:Book){
      booK.price = 88
    }
   }

