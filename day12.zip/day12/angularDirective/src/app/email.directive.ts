import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appEmail]'
})
export class EmailDirective {
  element: any;

  constructor() { }
  @HostListener('focus') onFocus(){
    console.log('FOCUS')
  }

@HostListener('blur') onBlur(){
  console.log('BLUR')
  let v = this.element.nativeElement.value
  if(!v.inclues('@')){
    this.element.nativeElement.value = v+ '@gmail.com'
 }
 else{
  this.element.nativeElement.value = v.toUpperCase()
 }
}

}
