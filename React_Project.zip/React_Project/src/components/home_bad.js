import React from "react";
import ReactDOM from 'react-dom/client';
import avatar_doctor from './images/doctor.png'
import avatar_afro from './images/afro.svg'


const Home = function(){
    return(
        <div className="ui raised very padded text container segment" style={{marginTop:"3em"}}>
            <h2 className="ui header">Home</h2>
            <p>Some text home.js</p>
        </div>
    )
}


const App = function(){
  return(
 <div className='ui comments'>
 
   
    name='Mr. Happy'
    date='09:30AM'
    msg="I'm feeling amazing"
   picture={avatar_doctor}
    />
  
   <User
     name='Ms. Joy'
     date='03:30AM'
     msg="I'm feeling joyous"
     picture={avatar_afro}
   />
  
   
   <User
    name='Ms. Glad'
    date='01:30PM'
    msg="I'm feeling glad"
    picture={avatar_doctor}
    />
   
   </div>

  )
}


//rooting
const root =ReactDOM.createRoot(document.querySelector('#root'))
root.render(App())


/*
//example of props
const App = function(props) {
  return(
    <div>
      <h1>Welcome to React function components{PaymentResponse.name}</h1> 
      </div>
  )
  }
// create a props in a constant
const myElement= <App name='Martha'/>


//rooting
ReactDOM.render(
  myElement, document.querySelector('#root')
)
*/





export default Home;