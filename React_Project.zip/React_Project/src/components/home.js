import React from "react";


const Home = function(){
    return(
        <div className="ui raised very padded text container segment" style={{marginTop:"3em"}}>
            <h2 className="ui header">Home</h2>
            <p>Class for Software Class</p>
        </div>
    )
}
export default Home;