import React from "react";
import { Outlet, Link } from "react-router-dom";

const Navbar = function(){
    return(
          <>
        <nav className="ui raised very padded segment">
            <a className="ui blue inverted segment" > Sue Peters React Project </a>
           <div className="ui right floated header">
            <button className="ui button"> <Link to='/'>Home</Link></button>
            <button className="ui button"> <Link to ='/form'>Contact Us</Link></button>
            <button className="ui button"> <Link to ='/HemisphereDisplay'>Geolocation</Link></button>
            <button className="ui button"> <Link to ='/ImageList'>Image Seacher</Link></button>
           </div>
        </nav>
        <Outlet/>
      </>  
        
    )
}
export default Navbar;