import React from "react";

const Image_List = function(props){
    const images = props.images.map(
         (images)=>{
            return <img key={images.id} scr={images.webFormatURL} alt="image"/>
         })
    return(
        <div>
          <p>My Images list</p>
          {images}
        </div>
    )
}
export default Image_List;