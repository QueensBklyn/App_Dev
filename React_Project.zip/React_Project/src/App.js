import React from "react";
import { BrowserRouter, Route, Routes} from "react-router-dom";
import About from './components/about';
import Home from './components/home';
import Contact from './components/contact';
import Form from './components/Form';
import Navbar from "./components/navbars";
import Searchinput from "./components/Searchinput";
import Image_List from "./components/ImageList";
import Hemisphere_Display from "./components/HemisphereDisplay";

//const App = function(){
  function App(){
  return(
      <div className="App">
        <BrowserRouter>
          <Navbar />
          <Routes >
              <Route path="/" element={<Navbar/>} />
              <Route index element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/form" element={<Form />} />
              <Route path="/searchinput" element={<Searchinput/>} />
              <Route path="/HemisphereDisplay" element={<Hemisphere_Display/>} />
              <Route path="/ImageList" element={<Image_List/>} />
          </Routes>
       </BrowserRouter>
      </div>
  )
}
export default App;
