Data About New York City
New York, often called New York City[a] or NYC, is the most populous city in the United States.
 With a 2020 population of 8,804,190 distributed over 300.46 square miles (778.2 km2),
  New York City is the most densely populated major city in the United States. 
  The city is more than twice as populous as Los Angeles, the nation's second-largest city. 
  New York City is situated at the southern tip of New York State. Situated on one of the world's 
  largest natural harbors, New York City comprises five boroughs, each of which is coextensive with 
  a respective county. The five boroughs, which were created in 1898 when local governments were c
  onsolidated into a single municipality, are: Brooklyn (Kings County), Queens (Queens County), 
  Manhattan (New York County), the Bronx (Bronx County), and Staten Island (Richmond County).[11]
   New York City is a global city and a cultural, financial, high-tech,[12] entertainment, glamor,[13]
    and media center with a significant influence on commerce, health care and scientific output 
    in life sciences,[14][15] research, technology, education, politics, tourism, dining, art, 
    fashion, and sports. Home to the headquarters of the United Nations, New York is an important
     center for international diplomacy,[16][17] and it is sometimes 
described as the world's most important city[18] and the capital of the world.[19][20]