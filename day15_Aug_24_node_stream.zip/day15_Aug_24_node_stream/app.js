const fs = require ('fs')

//importing the http module
const http=require('http')

//create a readable stream to read file readme.txt. This will fill up the buffer

const writestream = fs.createWriteStream('write.txt')

//CREATE A SERVER IN NODEJS
const server = http.createServer((request, response) =>{
    response.writeHead(200, { 'Content-Type': 'text/html' });
    const url = request.url

  if(url==='/home'|| url ==='/'){
      fs.createReadStream('index.html').pipe(response)
  }
  else if (url==='/about'){
    fs.createReadStream('about.html').pipe(response)
  }
  else{
    fs.createReadStream('404.html').pipe(response)
  }
})

//server listerning to port 3000
server.listen((3000), ()=>{
    console.log('Server is running at localhost:3000')
})


