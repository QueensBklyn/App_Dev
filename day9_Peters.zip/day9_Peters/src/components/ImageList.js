import React from "react";

const Images_List = function(props){
    const images = props.images.map(
         (images) =>{
            return <img scr={"image.webFormatURL"} alt="image" key={images.id}/>
         }

    )

    return(
        <div>
          <p>My Images list</p>
          {images}
        </div>
    )
}
export default Images_List;