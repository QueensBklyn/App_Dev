const user = require('./mod')

console.log(user.helper('Peter'))
console.log(user.id(123))
console.log(user.email('peterpan@neverland.com'))




function callColor(innerfunction){
    innerfunction()
}

let color = function(){
    console.log('Passing a function')
}

console.log(callColor(color))
/*
let count = 0

const timer = setInterval(() => {
     count += 2
     console.log(`counting = ${count} seconds`) 
     if (count ==10{
         clearInterval(timer)
     }
}, 2000);

// global objects
setTimeout(()=>{
    console.lob('Welcome to node.js')
*/