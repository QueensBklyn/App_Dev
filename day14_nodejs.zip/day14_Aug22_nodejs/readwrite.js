const fs = require('fs')

fs.rmdirSync('newDir')
fs.mkdirSync('newDir')

fs.mkdir('images',function(e){
    if(e){
        console.log(e)
    }
    console.log('image directory created successfully!')
})

//create a synchronous file using writeFileSync()
let fileContent = 'This file has three names:\n1. Peter\n2. Martha\n3. Jason'
fs.writeFileSync('write.txt', fileContent, 'utf-8')


//create an asynchronous file using writeFile
let msg='Welcome to nodjs I/O files'
fs.writeFile('msg.txt', msg, 'utf-8', function(e){
    if(e){
        console.log(e)
    }
} )

//append information into an exisiting file
let addNames = '4. George\n5. Ann'
fs.appendFileSync('write.txt', addNames, 'utf-8', function(error){
    if(error){
        console.log(error)
    }
})

//remove an existing file
fs.unlink('message.txt', function(error){
    console.log(error)
})

// asynchronous read module
console.log('Line before readFile')

fs.readFile('readme.txt', 'utf-8', function(error, data){
    console.log('\n\n-------- asynch read file --------')
    console.log(data)
})

console.log('Line after readFile')
let sum = 5+20
console.log(`Sum = ${sum}`)

// synchronous read module

console.log('Line before readFileSyn')

let fileRead =fs.readFileSync('readme.txt','utf-8')
console.log(fileRead)
console.log('Line after readFileSyn')